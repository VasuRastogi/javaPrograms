package OnlineClass.Example;

public class saichetan {

    public static void main(String[] args) {
//        if (args.length != 9)
//            System.out.println("Please enter 9 integer numbers");
//
//        int[][] array = new int[3][3];
//        int x = 0;
//
//        // storing input to 2d array
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
//                array[i][j] = Integer.parseInt(args[x++]);
//            }
//        }
//        // printing array
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
//                System.out.print(array[i][j]+" ");
//            }
//            System.out.println("");
//        }
//
//        int max = 0;
//
//        // getting max of array
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
////                max = array[i][j] > max ? array[i][j] : max;
//                if(max<array[i][j])
//                    max = array[i][j];
//            }
//        }
//
//        System.out.println("The biggest number in the given array is " + max);
        System.err.println("good");
    }

}
