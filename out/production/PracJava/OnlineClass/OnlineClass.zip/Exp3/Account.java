//(c)VasuRastogi (github) 20BCS5135
package OnlineClass.Exp3;

abstract class Account {  //blueprint of the account.
    double interestRate;
    double amount;
    int age;

    public static double calculateInterest () {
        try {
            // statement.
        }catch(Exception e){System.out.println("");}
        return 0;
    }
}
