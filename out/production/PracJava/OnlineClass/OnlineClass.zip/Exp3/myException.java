//(c)VasuRastogi (github) 20BCS5135
package OnlineClass.Exp3;

public class myException extends Exception{
    public myException(String str)
    {
        super(str);
    }
}
