package OnlineClass.Exp2;

public class myException extends Exception {

    public myException(String str)
    {
        super(str);
    }
}
